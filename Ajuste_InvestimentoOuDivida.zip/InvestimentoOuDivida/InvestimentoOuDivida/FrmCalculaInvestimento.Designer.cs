﻿namespace InvestimentoOuDivida
{
    partial class FrmCalculaInvestimento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtcalcular = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtvalor = new System.Windows.Forms.TextBox();
            this.txtpercentual = new System.Windows.Forms.TextBox();
            this.rdbinvestimento = new System.Windows.Forms.RadioButton();
            this.rdbdivida = new System.Windows.Forms.RadioButton();
            this.lblresultado = new System.Windows.Forms.Label();
            this.txtresultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtcalcular
            // 
            this.txtcalcular.Location = new System.Drawing.Point(175, 153);
            this.txtcalcular.Name = "txtcalcular";
            this.txtcalcular.Size = new System.Drawing.Size(75, 23);
            this.txtcalcular.TabIndex = 0;
            this.txtcalcular.Text = "Calcular";
            this.txtcalcular.UseVisualStyleBackColor = true;
            this.txtcalcular.Click += new System.EventHandler(this.txtcalcular_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Valor:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(251, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "%";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtvalor
            // 
            this.txtvalor.Location = new System.Drawing.Point(86, 54);
            this.txtvalor.Name = "txtvalor";
            this.txtvalor.Size = new System.Drawing.Size(100, 20);
            this.txtvalor.TabIndex = 3;
            // 
            // txtpercentual
            // 
            this.txtpercentual.Location = new System.Drawing.Point(281, 54);
            this.txtpercentual.Name = "txtpercentual";
            this.txtpercentual.Size = new System.Drawing.Size(100, 20);
            this.txtpercentual.TabIndex = 4;
            // 
            // rdbinvestimento
            // 
            this.rdbinvestimento.AutoSize = true;
            this.rdbinvestimento.Location = new System.Drawing.Point(86, 115);
            this.rdbinvestimento.Name = "rdbinvestimento";
            this.rdbinvestimento.Size = new System.Drawing.Size(85, 17);
            this.rdbinvestimento.TabIndex = 5;
            this.rdbinvestimento.TabStop = true;
            this.rdbinvestimento.Text = "Investimento";
            this.rdbinvestimento.UseVisualStyleBackColor = true;
            this.rdbinvestimento.CheckedChanged += new System.EventHandler(this.rdbinvestimento_CheckedChanged);
            // 
            // rdbdivida
            // 
            this.rdbdivida.AutoSize = true;
            this.rdbdivida.Location = new System.Drawing.Point(293, 115);
            this.rdbdivida.Name = "rdbdivida";
            this.rdbdivida.Size = new System.Drawing.Size(55, 17);
            this.rdbdivida.TabIndex = 6;
            this.rdbdivida.TabStop = true;
            this.rdbdivida.Text = "Divida";
            this.rdbdivida.UseVisualStyleBackColor = true;
            this.rdbdivida.CheckedChanged += new System.EventHandler(this.rdbdivida_CheckedChanged);
            // 
            // lblresultado
            // 
            this.lblresultado.AutoSize = true;
            this.lblresultado.BackColor = System.Drawing.Color.Cornsilk;
            this.lblresultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblresultado.ForeColor = System.Drawing.Color.Blue;
            this.lblresultado.Location = new System.Drawing.Point(116, 206);
            this.lblresultado.Name = "lblresultado";
            this.lblresultado.Size = new System.Drawing.Size(80, 13);
            this.lblresultado.TabIndex = 7;
            this.lblresultado.Text = "Lucro Obtido";
            // 
            // txtresultado
            // 
            this.txtresultado.BackColor = System.Drawing.Color.Yellow;
            this.txtresultado.Enabled = false;
            this.txtresultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtresultado.Location = new System.Drawing.Point(228, 203);
            this.txtresultado.Name = "txtresultado";
            this.txtresultado.Size = new System.Drawing.Size(100, 20);
            this.txtresultado.TabIndex = 8;
            // 
            // FrmCalculaInvestimento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 268);
            this.Controls.Add(this.txtresultado);
            this.Controls.Add(this.lblresultado);
            this.Controls.Add(this.rdbdivida);
            this.Controls.Add(this.rdbinvestimento);
            this.Controls.Add(this.txtpercentual);
            this.Controls.Add(this.txtvalor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtcalcular);
            this.Name = "FrmCalculaInvestimento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmCalculaInvestimento";
            this.Load += new System.EventHandler(this.FrmCalculaInvestimento_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button txtcalcular;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtvalor;
        private System.Windows.Forms.TextBox txtpercentual;
        private System.Windows.Forms.RadioButton rdbinvestimento;
        private System.Windows.Forms.RadioButton rdbdivida;
        private System.Windows.Forms.Label lblresultado;
        private System.Windows.Forms.TextBox txtresultado;
    }
}