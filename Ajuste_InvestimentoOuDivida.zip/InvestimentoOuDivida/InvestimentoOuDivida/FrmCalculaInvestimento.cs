﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvestimentoOuDivida
{
    public partial class FrmCalculaInvestimento : Form
    {
        double resulttado;

        

        public FrmCalculaInvestimento()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void FrmCalculaInvestimento_Load(object sender, EventArgs e)
        {

        }

        private void txtcalcular_Click(object sender, EventArgs e)
        {
            if (rdbinvestimento.Checked)
            {
                lblresultado.Text = "Lucro Obtido";
                lblresultado.ForeColor = Color.Blue;
                try
                {
                    int vallor = Convert.ToInt32(txtvalor.Text);
                    double percentt = Convert.ToDouble(txtpercentual.Text);
                    resulttado = vallor + (vallor * percentt/100);
                    txtresultado.Text = resulttado.ToString();

                } catch (FormatException)
                {
                    MessageBox.Show("Valor inserido Inválido , apenas números inteiros", "Erro", MessageBoxButtons.OK);
                }

            } else if(rdbdivida.Checked)
            {
                lblresultado.Text = "Prejuízo";
                lblresultado.ForeColor = Color.Red;
                try
                {
                    int vallor = Convert.ToInt32(txtvalor.Text);
                    double percentt = Convert.ToDouble(txtpercentual.Text);
                    resulttado = vallor - (vallor * (percentt/100));
                    txtresultado.Text = resulttado.ToString();
                }
                catch (FormatException)
                {
                    MessageBox.Show("Valor inserido Inválido , apenas números inteiros", "Erro", MessageBoxButtons.OK);
                }
            }
                 
        }

        private void rdbinvestimento_CheckedChanged(object sender, EventArgs e)
        {
            

        }

        private void rdbdivida_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}
