﻿namespace FrmControleConta
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnumero = new System.Windows.Forms.Label();
            this.lblsaldo = new System.Windows.Forms.Label();
            this.lbltitular = new System.Windows.Forms.Label();
            this.txtnumero = new System.Windows.Forms.TextBox();
            this.txtsaldo = new System.Windows.Forms.TextBox();
            this.cmbtitular = new System.Windows.Forms.ComboBox();
            this.btnnovo = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btngravar = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblnumero
            // 
            this.lblnumero.AutoSize = true;
            this.lblnumero.Location = new System.Drawing.Point(39, 68);
            this.lblnumero.Name = "lblnumero";
            this.lblnumero.Size = new System.Drawing.Size(54, 15);
            this.lblnumero.TabIndex = 0;
            this.lblnumero.Text = "Numero:";
            // 
            // lblsaldo
            // 
            this.lblsaldo.AutoSize = true;
            this.lblsaldo.Location = new System.Drawing.Point(229, 68);
            this.lblsaldo.Name = "lblsaldo";
            this.lblsaldo.Size = new System.Drawing.Size(39, 15);
            this.lblsaldo.TabIndex = 1;
            this.lblsaldo.Text = "Saldo:";
            // 
            // lbltitular
            // 
            this.lbltitular.AutoSize = true;
            this.lbltitular.Location = new System.Drawing.Point(39, 116);
            this.lbltitular.Name = "lbltitular";
            this.lbltitular.Size = new System.Drawing.Size(43, 15);
            this.lbltitular.TabIndex = 2;
            this.lbltitular.Text = "Titular:";
            // 
            // txtnumero
            // 
            this.txtnumero.Location = new System.Drawing.Point(99, 65);
            this.txtnumero.Name = "txtnumero";
            this.txtnumero.Size = new System.Drawing.Size(100, 23);
            this.txtnumero.TabIndex = 3;
            this.txtnumero.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtsaldo
            // 
            this.txtsaldo.Location = new System.Drawing.Point(274, 65);
            this.txtsaldo.Name = "txtsaldo";
            this.txtsaldo.Size = new System.Drawing.Size(100, 23);
            this.txtsaldo.TabIndex = 4;
            // 
            // cmbtitular
            // 
            this.cmbtitular.FormattingEnabled = true;
            this.cmbtitular.Location = new System.Drawing.Point(99, 108);
            this.cmbtitular.Name = "cmbtitular";
            this.cmbtitular.Size = new System.Drawing.Size(121, 23);
            this.cmbtitular.TabIndex = 5;
            // 
            // btnnovo
            // 
            this.btnnovo.Location = new System.Drawing.Point(287, 112);
            this.btnnovo.Name = "btnnovo";
            this.btnnovo.Size = new System.Drawing.Size(75, 23);
            this.btnnovo.TabIndex = 6;
            this.btnnovo.Text = "Novo";
            this.btnnovo.UseVisualStyleBackColor = true;
            this.btnnovo.Click += new System.EventHandler(this.btnnovo_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(287, 163);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(75, 23);
            this.btnsair.TabIndex = 7;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(167, 163);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(75, 23);
            this.btnlimpar.TabIndex = 8;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btngravar
            // 
            this.btngravar.Location = new System.Drawing.Point(56, 163);
            this.btngravar.Name = "btngravar";
            this.btngravar.Size = new System.Drawing.Size(75, 23);
            this.btngravar.TabIndex = 9;
            this.btngravar.Text = "Gravar";
            this.btngravar.UseVisualStyleBackColor = true;
            this.btngravar.Click += new System.EventHandler(this.btngravar_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(56, 214);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(337, 169);
            this.listBox1.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 402);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.btngravar);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnnovo);
            this.Controls.Add(this.cmbtitular);
            this.Controls.Add(this.txtsaldo);
            this.Controls.Add(this.txtnumero);
            this.Controls.Add(this.lbltitular);
            this.Controls.Add(this.lblsaldo);
            this.Controls.Add(this.lblnumero);
            this.Name = "Form1";
            this.Text = "Nova Conta";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnumero;
        private System.Windows.Forms.Label lblsaldo;
        private System.Windows.Forms.Label lbltitular;
        private System.Windows.Forms.TextBox txtnumero;
        private System.Windows.Forms.TextBox txtsaldo;
        private System.Windows.Forms.ComboBox cmbtitular;
        private System.Windows.Forms.Button btnnovo;
        private System.Windows.Forms.Button btnsair;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btngravar;
        private System.Windows.Forms.ListBox listBox1;
    }
}

