﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ControConta2;


namespace FrmControleConta
{
    public partial class Form1 : Form
    {
        //List<Conta> contas = new List<Conta>();
        public static List<Cliente> clientes = new List<Cliente>();
        public Form1()
        {
            InitializeComponent();
            clientes.Add(new Cliente("Pedro", "12345678901"));
            clientes.Add(new Cliente("Kenia", "10987654321"));
            listBox1.Items.Clear();
            listBox1.Items.Add("Nome\tCPF\tTitular");

            cmbtitular.Items.Clear();
            clientes.ForEach(delegate (Cliente cli)
            {
                cmbtitular.Items.Add(cli.Nome);
            });
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btngravar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(txtnumero.Text + "\t" + txtsaldo.Text + "\t" + cmbtitular.SelectedItem.ToString());
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnumero.Text = "";
            txtsaldo.Text = "";
            cmbtitular.Text = "";
            listBox1.Items.Clear();
            listBox1.Items.Add("Nome\tCPF\tTitular");

        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            DialogResult sair = MessageBox.Show("Confirmar saída?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (sair.Equals(DialogResult.Yes))
            {
                Application.Exit();
            }
        }

        private void btnnovo_Click(object sender, EventArgs e)
        {
            Form formCliente = new Form2();
            formCliente.ShowDialog();
        }
    }
}
