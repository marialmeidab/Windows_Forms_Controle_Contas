﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ControConta2;

namespace FrmControleConta
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnsalvar_Click(object sender, EventArgs e)
        {
            Form1.clientes.Add(new Cliente(txtnome.Text, txtcpf.Text));
            MessageBox.Show("Adicionado com sucesso", "Salvo", MessageBoxButtons.OK);
            txtnome.Text = " ";
            txtcpf.Text = " ";
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = (Form1)Application.OpenForms["Form1"];
            ComboBox cb = (ComboBox)f1.Controls["cmbtitular"];


            cb.Items.Clear();
            Form1.clientes.ForEach(delegate (Cliente cli)
            {
               
                cb.Items.Add(cli.Nome);
            }
           );
            this.Close();
        }
    }
}
